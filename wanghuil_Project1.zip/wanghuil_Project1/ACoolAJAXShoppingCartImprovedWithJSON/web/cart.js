// Timestamp of cart that page was last updated with
var lastCartUpdate = 0;

/*
 * Adds the specified item to the shopping cart, via Ajax call
 * itemCode - product code of the item to add
 */
function addToCart(itemCode) {
    var req = newXMLHttpRequest();
    //create new xml http request
    req.onreadystatechange = getReadyStateHandler(req, updateCart);
    //create on readyt state change handler
    req.open("POST", "cart.do", true);
    req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    req.send("action=add&item=" + itemCode);
    //open cart and send request of adding item
}

function removeFromCart(itemCode) {
    var req = newXMLHttpRequest();
    //create new xml http request
    req.onreadystatechange = getReadyStateHandler(req, updateCart);
    //create on readyt state change handler
    req.open("POST", "cart.do", true);
    req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    req.send("action=remove&item=" + itemCode);
    //open cart and send request of removing item
}

/*
 * Update shopping-cart area of page to reflect contents of cart
 * described in Json document.
 */
function updateCart(cartJSON) {
    var myCart = JSON.parse(cartJSON);
    var generated = myCart.cart.Generated;
    //get cart generated attribute
    if (generated > lastCartUpdate) {
        lastCartUpdate = generated;
        //update lastCartUpdate to generated
        var contents = document.getElementById("contents");
        //get element of id:contents
        contents.innerHTML = "";
        //clear content html

        var items = myCart.cart.cartItems;
        for (var I = 0; I < items.length; I++) {

            var item = items[I];
            var name = item.name;
            var quantity = item.quantity;

            var listItem = document.createElement("li");
            listItem.appendChild(document.createTextNode(name + " x " + quantity));
            contents.appendChild(listItem);
        }
        //add items into cart
        document.getElementById("total").innerHTML = myCart.cart.Total;
        //get total
    }
}