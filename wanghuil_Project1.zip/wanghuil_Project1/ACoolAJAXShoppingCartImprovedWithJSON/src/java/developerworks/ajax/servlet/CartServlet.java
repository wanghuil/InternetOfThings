
package developerworks.ajax.servlet;

import developerworks.ajax.store.Cart;
import javax.servlet.http.*;

import java.util.Enumeration;

public class CartServlet extends HttpServlet {

  /**
   * Updates Cart, and outputs XML representation of contents
   */
  public void doPost(HttpServletRequest req, HttpServletResponse res) throws java.io.IOException {

    Enumeration headers = req.getHeaderNames();
    //get header names
    while (headers.hasMoreElements()) {
      String header  =(String) headers.nextElement();
      System.out.println(header+": "+req.getHeader(header));
    }
    //print header names
    Cart cart = getCartFromSession(req);
    //get cart from session
    String action = req.getParameter("action");
    String item = req.getParameter("item");
    //create string to represent action and item
    if ((action != null)&&(item != null)) {
    //add or delete items if action and item are not null
      if ("add".equals(action)) {
        cart.addItem(item);

      } else if ("remove".equals(action)) {
        cart.removeItems(item);

      }
    }
    //make cart to Json string 
    String cartJson = cart.toJson();
    //for Json to return back 
    res.setContentType("application/Json");
    //for user to get Json
    res.getWriter().write(cartJson);
  }

  public void doGet(HttpServletRequest req, HttpServletResponse res) throws java.io.IOException {
    // Bounce to post, for debugging use
    // Hit this servlet directly from the browser to see XML
    doPost(req,res);
  }

  private Cart getCartFromSession(HttpServletRequest req) {

    HttpSession session = req.getSession(true);
    //get session if there is one
    Cart cart = (Cart)session.getAttribute("cart");
   //get cart from session 
    if (cart == null) {
      cart = new Cart();
      session.setAttribute("cart", cart);
    }
    
    return cart;
  }
  //create a cart if there is no cart
}
