var lastCartUpdate = 0;
var websocket;

//sent text
function sendText(mesg) {
    console.log("sending text: " + mesg);
    websocket.send(mesg);
}

//init websocket
function init() {
    var wsUri = "ws://" + document.location.host + document.location.pathname + "websocket";
    websocket = new WebSocket(wsUri);

    websocket.onopen = function (evt) {
        onOpen(evt)
    };

    websocket.onclose = function (evt) {
        onClose(evt)
    };

    websocket.onmessage = function (evt) {
        onMessage(evt)
    };
    websocket.onerror = function (evt) {
        onError(evt)
    };

}
//connect and reload
function onOpen(evt) {
    console.log("CONNECTED");
    sendText(JSON.stringify({action: "reload", item: "reload"}));
}
//close
function onClose(evt) {
    writeToScreen("DISCONNECTED");
}
//update
function onMessage(evt) {
    updateCart(evt.data);
}
//error
function onError(evt) {
    writeToScreen('<span style="color: red;">ERROR:</span> ' + evt.data);
}




//json add to cart using item code
function addToCart(itemCode) {
    sendText(JSON.stringify({action: "add", item: itemCode}));
}

//json remove from cart using item code
function removeFromCart(itemCode) {
    sendText(JSON.stringify({action: "remove", item: itemCode}));
}

function updateCart(cartJSON) {
    var myCart = JSON.parse(cartJSON);
    var generated = myCart.cart.Generated;
    //get cart generated attribute
    if (generated > lastCartUpdate) {
        lastCartUpdate = generated;
        //update lastCartUpdate to generated
        var contents = document.getElementById("contents");
        //get element of id:contents
        contents.innerHTML = "";
        //clear content html

        var items = myCart.cart.cartItems;
        for (var I = 0; I < items.length; I++) {

            var item = items[I];
            var name = item.name;
            var quantity = item.quantity;

            var listItem = document.createElement("li");
            listItem.appendChild(document.createTextNode(name + " x " + quantity));
            contents.appendChild(listItem);
        }
        //add items into cart
        document.getElementById("total").innerHTML = myCart.cart.Total;
        //get total
    }
}



