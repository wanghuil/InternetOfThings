package developerworks.ajax.store;

import java.math.BigDecimal;
import java.util.*;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;

/**
 * A very simple shopping Cart
 */
public class Cart {

    private HashMap<Item, Integer> contents;

    /**
     * Creates a new Cart instance
     */
    public Cart() {
        contents = new HashMap<Item, Integer>();
    }

    /**
     * Adds a named item to the cart
     *
     * @param itemName The name of the item to add to the cart
     */
    public void addItem(String itemCode) {
        Catalog catalog = new Catalog();
        if (catalog.containsItem(itemCode)) {
            Item item = catalog.getItem(itemCode);
            int newQuantity = 1;
            //make the item quantity of 1
            if (contents.containsKey(item)) {
                Integer currentQuantity = contents.get(item);
                newQuantity += currentQuantity.intValue();
            }
            //update the quantity
            contents.put(item, new Integer(newQuantity));
            //if the item was not in the cart, make the quantity of 1
        }
    }

    /**
     * Removes the named item from the cart
     *
     * @param itemName Name of item to remove
     */
    public void removeItems(String itemCode) {
        Catalog catalog = new Catalog();
        if (catalog.containsItem(itemCode)) {
            int newQuantity;
            Item item = catalog.getItem(itemCode);
            if (contents.containsKey(item)) {
                Integer currentQuantity = contents.get(item);
                newQuantity = currentQuantity.intValue() - 1;
                 // subtracting 1 from the quantity
                if (newQuantity > 0) {
                    contents.put(item, new Integer(newQuantity));
                    //update the quantity
                } else {
                    contents.remove(item);
                    //if quantity is 0, remove the item
                }
            }
        }
    }

    /**
     * @return Json representation of cart contents
     */
    public String toJson() {
        StringBuffer json = new StringBuffer();
        //transfer json to json format
        json.append("{\"cart\":{\"Generated\":"+System.currentTimeMillis()+",\"Total\":\""+getCartTotal()+"\",\"cartItems\":[");
        
        for (Iterator<Item> I = contents.keySet().iterator(); I.hasNext();) {
            Item item = I.next();
            int itemQuantity = contents.get(item);
            
            json.append("{\"code\":\""+item.getCode()+"\",");
            json.append("\"name\":\""+item.getName()+"\",");
            json.append("\"quantity\":"+itemQuantity+"}");
            if (I.hasNext()) {
                json.append(",");
            }
        }
        json.append("]}}");
        //transfer stringBuffer json to a string(add code, name, quantity)
        return json.toString();
    }

    private String getCartTotal() {
        int total = 0;
        
        for (Iterator<Item> I = contents.keySet().iterator(); I.hasNext();) {
            Item item = I.next();
            int itemQuantity = contents.get(item);
            total += (item.getPrice() * itemQuantity);
        }
        return "$" + new BigDecimal(total).movePointLeft(2);
        //get total
    }
}