
package developerworks.ajax.servlet;

import developerworks.ajax.store.Cart;
import developerworks.ajax.store.Item;
import java.io.StringReader;
import java.util.HashMap;
import javax.json.Json;
import javax.json.JsonException;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EndpointConfig;


public class CartDecoder implements Decoder.Text<Cart> {

    public static Cart myCart=new Cart ();


    
    @Override
    public Cart decode(String msg) throws DecodeException {
        // trasfer string into jsonObject
        JsonReader jsonReader = Json.createReader(new StringReader(msg));
        JsonObject jsonObject = jsonReader.readObject();  
        
        String action = jsonObject.getString("action");
        String item = jsonObject.getString("item");
        
        if ((action != null) && (item != null)) {
            //add or remove or reload item
            if ("add".equals(action)) {
                myCart.addItem(item);
            } else if ("remove".equals(action)) {
                myCart.removeItems(item);
            } else if ("reload".equals(action)) {
                return myCart;
            }
        }
        return myCart;
    }

    @Override
    public boolean willDecode(String msg) {
        try {
            JsonReader jsonReader = Json.createReader(new StringReader(msg));
            JsonObject jsonObject = jsonReader.readObject();
            return true;
        } catch (JsonException ex) {
            System.out.println("will decode");
            return false;
        }
    }


    @Override
    public void init(EndpointConfig config) {
        System.out.println("init");
    }


    @Override
    public void destroy() {
        System.out.println("destroy");
    }

}