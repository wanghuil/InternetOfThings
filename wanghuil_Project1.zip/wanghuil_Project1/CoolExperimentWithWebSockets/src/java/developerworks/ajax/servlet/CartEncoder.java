
package developerworks.ajax.servlet;

import developerworks.ajax.store.Cart;
import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;


public class CartEncoder implements Encoder.Text<Cart>{

    @Override
    public String encode(Cart cart) throws EncodeException {
        //cart to json to string,return string
        return cart.toJson().toString();
    }

    @Override
    public void init(EndpointConfig config) {
        System.out.println("init");
    }

    @Override
    public void destroy() {
        System.out.println("destroy");
    }
    
}
