/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//function to do AJAX requests
function getSomeJSON(webRoute) {

    var xhr;

    // This blocks just checks if you are using and old version of IE
    if (window.XMLHttpRequest)
        xhr = new XMLHttpRequest();
    else
        xhr = ActiveXObject("Microsoft.XMLHTTP");

    //Specifies what to do when the response from the server arrives
    xhr.onreadystatechange = function () {

        // handle callback by calling handleJSON
        if (xhr.readyState == 4) {

            var result = xhr.responseText;
            //Calls the method passing the response text as the parameter
            handleJSON(result, webRoute);
        }
    }
    //Sets up and sends the request

    xhr.open("GET", "PhotonServlet", true);
    xhr.send(null);
}

//Manipulates the JSON and inserts the fulldate value in the page
function handleJSON(someJSONFromServer, webRoute) {
    // Use library to parse the string back from server

    var myJsonObj = JSON.parse(someJSONFromServer);
    var photon = myJsonObj.Photon;
    var id = photon.photonId;
    var time = photon.lastHeartBeat;
    if (webRoute == 2) {

        // Place the returnedValue in the DOM.
        // The id coolLocation is used to find the location.
        var contents = document.getElementById("PhotonInformation");

        // Erase current value
        contents.innerHTML = "";
        // Add the value of the JSON name, value pair.
        contents.appendChild(document.createTextNode("Photon ID:" + id + " Last Heart Beat:" + time));
    } else {
        document.open();
        document.write("<!DOCTYPE>\n\
                        <html>\n\
                           <head>\n\
                              <title>Photon Tracker</title>\n\
                           </head>\n\
                           <body>\n\
                              <h1>Photon Tracker</h1>\n\
                              <div>" +"Photon ID:"+ id + " Last Heart Beat:" + time + "</div>\n\
                           </body>\n\
                        </html>");
        document.close();
    }
}