/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author LiWH
 */
@WebServlet(name = "PhotonServlet", urlPatterns = {"/PhotonServlet"})
public class PhotonServlet extends HttpServlet {

    String id;
    Date heartBeat = new Date();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Photon Tracker</title>");
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>Photon Tracker</h1>");
//            out.println("</body>");
//            out.println("</html>");
//        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        // Bounce to post, for debugging use
        // Hit this servlet directly from the browser to see XML

        //if photon disconnected for more than 20 sec, show tag
        Date currentHeartBeat = new Date();
        if (currentHeartBeat.getTime() - heartBeat.getTime() > 20000) {
            String notice = "Disconnected for more than 20 sec";
            res.setContentType("application/json");
            res.getWriter().write(toJson(id, notice));
            System.out.println(toJson(id, notice));
            return;
        }
        //show time if connected
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String myHeartBeat = dateFormat.format(heartBeat);
        res.setContentType("application/json");
        res.getWriter().write(toJson(id, myHeartBeat));
        System.out.println(toJson(id, myHeartBeat));

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        id = req.getParameter("Photon_ID");
        Date newHeartBeat = new Date();
        //if photon send new message, update the time
        if (newHeartBeat.getTime() - heartBeat.getTime() > 0) {
            heartBeat = newHeartBeat;
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String aHeartBeat = dateFormat.format(heartBeat);
            res.setContentType("application/json");
            res.getWriter().write(toJson(id, aHeartBeat));
            System.out.println(toJson(id, aHeartBeat));
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    //to Json method
    protected String toJson(String id, String time) {
        StringBuilder json = new StringBuilder();
        json.append("{\"Photon\":{");
        json.append("\"photonId\":\"").append(id).append("\"");
        json.append(",\"lastHeartBeat\":\"").append(time).append("\"");
        json.append("}}");
        return json.toString();
    }

}
