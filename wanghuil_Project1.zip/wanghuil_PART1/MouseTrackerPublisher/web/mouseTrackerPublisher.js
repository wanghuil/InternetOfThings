/* global client, Paho */


client = new Paho.MQTT.Client("localhost", Number(8000), "MousePublisher");
//find paho on localhost, its location and name
client.onConnectionLost = onConnectionLost;
client.onMessageArrived = onMessageArrived;
client.connect({onSuccess: onConnect});
//find function on connection, connection lost and message arrived

function onConnect() {
    console.log("Broker Connected");
    //once connected, subscribing MouseTracker
};

function onConnectionLost(responseObject) {
    if (responseObject.errorCode !== 0)
        console.log("onConnectionLost:" + responseObject.errorMessage);
    //once connection lost send error message
};

function onMessageArrived(message) {
    console.log("onMessageArrived:" + message.payloadString);
    //once message arrived, print it
};

function myFunction(e) {
    var x = e.clientX;
    var y = e.clientY;
    var coor = "Coordinates: (" + x + "," + y + ")";
    //create x, y and coordinate including x, y
   message = new Paho.MQTT.Message(coor);
    //MQTT message for paho
    message.destinationName = "/MouseTracker";
    client.send(message);
    //send message to topic of MouseTracker
    message.qos=1;
    //publish message at one time
    //send message to topic of MouseTracker
    document.getElementById("demo").innerHTML = coor;
    //when mouse moves in the box, show coordinate(x, y) using id=demo
}


function clearCoor() {
    
    document.getElementById("demo").innerHTML = "";
    //when mouse moves out of box, show nothing
}