/* global num, google, globalCounter */

// Load google chart packages
google.charts.load('current', {'packages': ['corechart', 'line', 'gauge']});

// Calls function when the packages are correctly loaded
google.charts.setOnLoadCallback(drawCharts);

//Sets variables
var gaugedata;
var gaugechart;
var gaugeoptions;
var linedata;
var linechart;
var lineoptions;
var sum = 0;
//accummulated sum of die1 and die2
var rf2 = 0, rf3 = 0, rf4 = 0, rf5 = 0, rf6 = 0, rf7 = 0, rf8 = 0, rf9 = 0, rf10 = 0, rf11 = 0, rf12 = 0;
//relative frequency of sum2-12
var sum2 = 0, sum3 = 0, sum4 = 0, sum5 = 0, sum6 = 0, sum7 = 0, sum8 = 0, sum9 = 0, sum10 = 0, sum11 = 0, sum12 = 0;
//count number of sum1-12

//Draws initial graphs
function drawCharts() {

    //Sets data for the gauges
    gaugedata = google.visualization.arrayToDataTable([
        ['Label', 'Value'],
        ['guage1', 0],
        ['guage2', 0],
        ['guage3', 0],
        ['guage4', 0]
    ]);
//label from guage1 to guage4

    //Sets appearance options for the gauges
    gaugeoptions = {
        min: 1, max: 12,
        width: 400, height: 120,
        redFrom: 10, redTo: 12,
        yellowFrom: 6, yellowTo: 10,
        minorTicks: 0
    };
//set guage appearance, range from 2 to 12, and mintick as 0


    //Instantiates the gauges and the location
    gaugechart = new google.visualization.Gauge(document.getElementById('chart_div'));


    //Draws the gauges
    gaugechart.draw(gaugedata, gaugeoptions);



    // Creates the initial data for the line graph
    linedata = new google.visualization.DataTable();
    linedata.addColumn('number', 'X');
    linedata.addColumn('number', 'Dice');
    //x and y axis
    linedata.addRows([[2, 0], [3, 0], [4, 0], [5, 0], [6, 0], [7, 0], [8, 0], [9, 0], [10, 0], [11, 0], [12, 0]])
    
     
    //Sets appearance options for the line graph
    lineoptions =
            {
                hAxis:
                        {
                            title: '  Sum of Dice Rolling',
                            viewWindow:
                                    {
                                        max: 12,
                                        min: 2
                                    //range from 2 to 12 for x axis  
                                     
                                    },
                            gridlines: {count: 11}
                        },
                vAxis:
                        {
                            title: 'Relative Frequency',
                            viewWindow:
                                    {
                                        max: 1,
                                        min: 0
                                    //range from 0 to 1 for y axis
                                    }
                        }
            };

    //Instantiates the line chart and the location
    linechart = new google.visualization.LineChart(document.getElementById('line_div'));
    //Draws the line chart
    linechart.draw(linedata, lineoptions);
}





//Updates the values of the graphs with random data
function updateGauges(die1, die2)
{
    var d1 = Number(die1);
    var d2 = Number(die2);
    //convert json string to number


    //Updates each of the datapoints with a random number
    gaugedata.setValue(0, 1, d1);
    //show die1
    gaugedata.setValue(1, 1, d2);
    //show die2
    gaugedata.setValue(2, 1, d1 + d2);
    //show sum of die1 and die2
    sum += d1 + d2;
    var avg = sum / globalCounter;
    //calulate average number
    gaugedata.setValue(3, 1, avg);
    //show avg 
    if (d1 + d2 == 2) {
        sum2 += 1;
        rf2 = sum2 / globalCounter;
    } else if (d1 + d2 == 3) {
        sum3 += 1;
        rf3 = sum3 / globalCounter;
    } else if (d1 + d2 == 4) {
        sum4 += 1;
        rf4 = sum4 / globalCounter;
    } else if (d1 + d2 == 5) {
        sum5 += 1;
        rf5 = sum5 / globalCounter;
    } else if (d1 + d2 == 6) {
        sum6 += 1;
        rf6 = sum6 / globalCounter;
    } else if (d1 + d2 == 7) {
        sum7 += 1;
        rf7 = sum7 / globalCounter;
    } else if (d1 + d2 == 8) {
        sum8 += 1;
        rf8 = sum8 / globalCounter;
    } else if (d1 + d2 == 9) {
        sum9 += 1;
        rf9 = sum9 / globalCounter;
    } else if (d1 + d2 == 10) {
        sum10 += 1;
        rf10 = sum10 / globalCounter;
    } else if (d1 + d2 == 11) {
        sum11 += 1;
        rf11 = sum11 / globalCounter;
    } else if (d1 + d2 == 12) {
        sum12 += 1;
        rf12 = sum12 / globalCounter;
    }
    //count number of sum of die1 and die2
    //Redraws the gauges with the new data
    gaugechart.draw(gaugedata, gaugeoptions);



    //Sets frequecy values for each of the rows
    //rf2-11 represent frequency
    linedata.setValue(0, 1, rf2);
    linedata.setValue(1, 1, rf3);
    linedata.setValue(2, 1, rf4);
    linedata.setValue(3, 1, rf5);
    linedata.setValue(4, 1, rf6);
    linedata.setValue(5, 1, rf7);
    linedata.setValue(6, 1, rf8);
    linedata.setValue(7, 1, rf9);
    linedata.setValue(8, 1, rf10);
    linedata.setValue(9, 1, rf11);



    //Redraws the line chart with the updated data
    linechart.draw(linedata, lineoptions);
}/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


