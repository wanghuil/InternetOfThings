/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global client, previousSubscription, topic, message, Paho */

client = new Paho.MQTT.Client("localhost", Number(8000), "TemperatureSub");
//find paho on localhost, its location and name
client.onConnectionLost = onConnectionLost;
client.onMessageArrived = onMessageArrived;
client.connect({onSuccess: onConnect});
//function on connection, connection lost and message arrived
var topicSub = "temperature/pittsburgh/hotTemps";
//set subscribe topic=hot temperature

function onConnect() {
    //subcribe all temperature
    console.log("subscribed");
    client.subscribe("temperature/pittsburgh/#");
}
;

function onConnectionLost(responseObject) {
    if (responseObject.errorCode !== 0)
        console.log("onConnectionLost:" + responseObject.errorMessage);
    //once connection lost send error message
}
;


function onMessageArrived(message) {
    var myJsonObj = JSON.parse(message.payloadString);
    //read json of timestamp and temperature
    var topic = message.destinationName;
    //get topic
    if (topic === topicSub && topic === "temperature/pittsburgh/coldTemps") {
        document.getElementById("demo").innerHTML += "Subscribe temperature/pittsburgh/coldTemps." + message.payloadString + '<br />';
    // if select cold temperature button, show cold temperature
    } else if (topic === topicSub && topic === "temperature/pittsburgh/niceTemps") {
        document.getElementById("demo").innerHTML += "Subscribe temperature/pittsburgh/niceTemps." + message.payloadString + '<br />';
    // if select nice temperature button, show nice temperature
    } else if (topic === topicSub && topic === "temperature/pittsburgh/hotTemps") {
        document.getElementById("demo").innerHTML += "Subscribe temperature/pittsburgh/hotTemps." + message.payloadString + '<br />';
    // if select hot temperature button, show hot temperature
    } else if (topicSub === "temperature/pittsburgh/#") {
        document.getElementById("demo").innerHTML += "Subscribe temperature/pittsburgh/allTemps." + message.payloadString + '<br />';
    // if select all temperature button, show all temperature
    }

    var msg = "TimeStamp: " + myJsonObj.Timestamp + " Temperature: " + myJsonObj.Temperature;
    //show timestamp and temperature json to object
    console.log("onMessageArrived:" + message.payloadString);
    //once message arrived, print payloadString using id=demo
}
;


function coldTemp() {
    topicSub = "temperature/pittsburgh/coldTemps";
    //set cold temperature subtopic
}

function niceTemp() {
    topicSub = "temperature/pittsburgh/niceTemps";
    //set nice temperature subtopic
}

function highTemp() {
    topicSub = "temperature/pittsburgh/hotTemps";
    //set high temperature subtopic
}

function allTemp() {
    topicSub = "temperature/pittsburgh/#";
    //set all temperature subtopic
}










    