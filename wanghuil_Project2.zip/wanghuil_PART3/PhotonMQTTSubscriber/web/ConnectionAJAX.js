var loc = {'hostname' : 'localhost', 'port' : '8000' };
//set host name and port 
client = new Paho.MQTT.Client(loc.hostname, Number(loc.port), 'wanghuilSub');
//find paho on localhost, its location and name

client.onConnectionLost = onConnectionLost;
client.onMessageArrived = onMessageArrived;
client.connect({onSuccess:onConnect});
//function on connection, connection lost and message arrived

function onConnect() {
    console.log("Connection established, subscribing to student/wanghuil ");
    client.subscribe("student/id", {qos: 1});
    //set qos=1, subscrbe message
    //once connected, subscribing student/wanghuil
}

function onConnectionLost(responseObject) {
   if (responseObject.errorCode !== 0) {
        console.log("onConnectionLost:"+responseObject.errorMessage);
        //once connection lost send error message
   }
}

function onMessageArrived(message) {
    console.log("onMessageArrived:" + message.payloadString);
    var htmlDoc = document.getElementById("message"); 
     //once message arrived, print payloadString using id=message
    var newmsg = document.createElement("p");
    //create a new paragraph
    newmsg.innerHTML = message.payloadString; 
    htmlDoc.append(newmsg);
    //append new message
}