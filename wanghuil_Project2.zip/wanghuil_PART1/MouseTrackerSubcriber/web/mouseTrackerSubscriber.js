/* global client, Paho */

client = new Paho.MQTT.Client("localhost", Number(8000), "MouseSubscriber");
//find paho on localhost, its location and name
client.onConnectionLost = onConnectionLost;
client.onMessageArrived = onMessageArrived;
client.connect({onSuccess: onConnect});
//function on connection, connection lost and message arrived

function onConnect() {
    console.log("subscribed");
    client.subscribe("/MouseTracker");
    //once connected, subscribing MouseTracker
};

function onConnectionLost(responseObject) {
    if (responseObject.errorCode !== 0)
        console.log("onConnectionLost:" + responseObject.errorMessage);
    //once connection lost send error message
};

function onMessageArrived(message) {
    document.getElementById("demo").innerHTML = document.getElementById("demo").innerHTML+message.payloadString + '<br />';
    //get id=demo and toString, and change line
    console.log("onMessageArrived:" + message.payloadString);
    //once message arrived, print payloadString using id=demo
};