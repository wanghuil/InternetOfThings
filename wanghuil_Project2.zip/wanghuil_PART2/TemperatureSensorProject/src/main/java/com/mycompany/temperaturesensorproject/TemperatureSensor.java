package com.mycompany.temperaturesensorproject;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class TemperatureSensor {

    public static void main(String[] args) throws MqttException {
        String broker = "tcp://localhost:1883";
        //localhost=1883

        String client = "TemperaturePublisher";
        //Id for the client connected to MQTT broker

        MemoryPersistence mp = new MemoryPersistence();
        //save client id

        MqttClient mqClient = new MqttClient(broker, client, mp);
        //build mqtt client            
        MqttConnectOptions con = new MqttConnectOptions();
        con.setCleanSession(true);
        // set connection options
        mqClient.connect(con);
        // connecting to the MQTT broker
        

        Timer t = new Timer();
        //timer of 5000 millsecond
        t.schedule(new TimerTask() {
            @Override
            public void run() {
                //over ride timer run function      
                Random random = new Random();
                int range = 100;
                Double fa = random.nextDouble() * range;
                //set fa temperature from double

                Date date = new Date();
                SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                //format date 
                String form = sd.format(date);
                //get timestamp

                String topic;
                if (fa >= 0 && fa <= 45) {
                    topic = "temperature/pittsburgh/coldTemps";
                } else if (fa > 45 && fa <= 80) {
                    topic = "temperature/pittsburgh/niceTemps";
                } else {
                    topic = "temperature/pittsburgh/hotTemps";
                }
                //compare the temperature topic using temperature                   

                DecimalFormat fmt = new DecimalFormat("##0.0");
                String temp1 = fmt.format(fa);
               
                // format fa to 2 decimals and ccnvert it to string
                

                String content = "{\"Temperature\":" + "\"" + temp1 + "\"" + ",\"Timestamp\":" + "\"" + form + "\"" + "}";
                //create content of timestamp and temperature in json
                MqttMessage message = new MqttMessage(content.getBytes());
                //create a new MQTT message, get content
                int qos = 2;
                //only appear in publish message
                message.setQos(qos);
                //set qos
                
              
                try {
                    mqClient.publish(topic, message);
                    //client publish topic and message
                } catch (MqttException ex) {
                    Logger.getLogger(TemperatureSensor.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("Message:" + message);
                //print message

            }
        }, 0, 5000); 
    }

}
