package com.mycompany.dicerollingclientproject;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class DiceRollingClient {

    public static void main(String[] args) throws MqttException {
        String broker = "tcp://localhost:1883";
        //localhost=1883
        String client = "DiceRollingPublisher";
        //Id for the client connected to MQTT broker
        MemoryPersistence mp = new MemoryPersistence();
        //save client id      
        MqttClient mqClient = new MqttClient(broker, client, mp);
        //build mqtt client            
        MqttConnectOptions con = new MqttConnectOptions();
        con.setCleanSession(true);
        // set connection options
        mqClient.connect(con);
        // connecting to the MQTT broker

        Timer t = new Timer();
        //timer of 1000 millsecond

        t.schedule(new TimerTask() {
            @Override
            public void run() {

                Random random1 = new Random();
                Random random2 = new Random();
                int die1 = random1.nextInt(6) + 1;
                int die2 = random2.nextInt(6) + 1;
                //build random die1 and die2 between 1 and 6
                String topic = "/DiceRolling";
                //build topic=dice roll
                String dice1 = String.valueOf(die1);
                String dice2 = String.valueOf(die2);
                //convert int to string

                String content = "{\"Die1\":" + "\"" + dice1 + "\"" + ",\"Die2\":" + "\"" + dice2 + "\"" + "}";
                //publish number of die1 and die2

                MqttMessage message = new MqttMessage(content.getBytes());
                //create a new MQTT message, get content
                int qos = 2;
                //only appear in publish message
                message.setQos(qos);
                //set qos

                try {
                    mqClient.publish(topic, message);
                    //client publish topic and message
                } catch (MqttException ex) {
                    Logger.getLogger(DiceRollingClient.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("Message:" + message);
                //print message
            }
        }, 0, 1000);
    }
}
