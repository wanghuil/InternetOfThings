/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global Paho, onConnectionLost, onMessageArrived, onConnect, google, drawChart, gaugeData1, gaugeData2, client, gaugeData3, options, chart */

client = new Paho.MQTT.Client("localhost", Number(8000), "DiceMonitor");
//find paho on localhost, its location and name
client.onConnectionLost = onConnectionLost;
client.onMessageArrived = onMessageArrived;
client.connect({onSuccess: onConnect});

var globalCounter = 0;
function onConnect() {
    //subcribe dice rolling
    client.subscribe("/DiceRolling");
    console.log("subscribed");

}
;

function onConnectionLost(responseObject) {
    if (responseObject.errorCode !== 0)
        console.log("onConnectionLost:" + responseObject.errorMessage);
    //once connection lost send error message
}
;

function onMessageArrived(message) {
    var myJsonObj = JSON.parse(message.payloadString);
    globalCounter += 1;
    console.log(globalCounter);
    // read json of die1 and die2
    var die1 = myJsonObj.Die1;
    var die2 = myJsonObj.Die2;
    //update guages
    updateGauges(die1, die2);
}
;

